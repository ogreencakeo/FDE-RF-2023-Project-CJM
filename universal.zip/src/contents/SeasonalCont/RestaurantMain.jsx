import { RecommSeasonal } from "./RecommSeasonal";

export function RestaurantMain(){
    return(
        <>
            <RecommSeasonal />
        </>
    )
}