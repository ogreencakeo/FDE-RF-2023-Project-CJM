import { createContext } from "react";

export const universalCon = createContext();