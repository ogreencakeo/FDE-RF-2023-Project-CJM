export const food_recommmed = [
    {
        "img" : "recommendations1.jpg",
        "txt" : "저알레르기 메뉴",
        "cont" : "일부 레스토랑에서 특정 알레르기에 대응한 ‘저알레르기 메뉴’를 준비하고 있습니다."
    },
    {
        "img" : "recommendations2.jpg",
        "txt" : "어린이 메뉴 특집",
        "cont" : "어린이에게 인기 있는 메뉴가 총집합!"
    },
    {
        "img" : "recommendations1.jpg",
        "txt" : "길거리 음식 특집",
        "cont" : "일부 레스토랑에서 특정 알레르기에 대응한 ‘저알레르기 메뉴’를 준비하고 있습니다."
    },
    {
        "img" : "recommendations1.jpg",
        "txt" : "저알레르기 메뉴",
        "cont" : "일부 레스토랑에서 특정 알레르기에 대응한 ‘저알레르기 메뉴’를 준비하고 있습니다."
    },
    {
        "img" : "recommendations1.jpg",
        "txt" : "저알레르기 메뉴",
        "cont" : "일부 레스토랑에서 특정 알레르기에 대응한 ‘저알레르기 메뉴’를 준비하고 있습니다."
    },
    {
        "img" : "recommendations1.jpg",
        "txt" : "저알레르기 메뉴",
        "cont" : "일부 레스토랑에서 특정 알레르기에 대응한 ‘저알레르기 메뉴’를 준비하고 있습니다."
    },
];
