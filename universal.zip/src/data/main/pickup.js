export const pickUpData = [
    {
        title: "NO LIMIT! 크리스마스",
        cont: "개최기간：2023년11월 21일(화) ~ 2024년1월 8일(월)",
        emotion: "gifts",
        img: "pickup1.jpg",
    },
    {
        title: "‘스파이더맨 더 라이드’ 파이널 이벤트",
        cont: "개최기간：2023년7월 4일(화) ~ 2024년1월 22일(월)",
        emotion: "spider",
        img: "pickup2.jpg",
    },
    {
        title: "“슈퍼 닌텐도 월드™”",
        cont: "현재 운영 중!",
        emotion: "chessKing",
        img: "pickup3.jpg",
    },
    {
        title: "매지컬 크리처스 인카운터 ~마법 생물과의 만남~",
        cont: "개최기간：2023년3월 17일(금) ~ 12월 31일(일)",
        emotion: "hatWizard",
        img: "pickup4.jpg",
    },
    {
        title: "“NO LIMIT! 퍼레이드”",
        cont: "개최기간：2023년3월 1일(수) ~",
        emotion: "mountainSun",
        img: "pickup5.jpg",
    },
    {
        title: "사다코의 저주 ~다크 호러 라이드~",
        cont: "개최기간：2023년 9월 24일 (일)~2024년 1월 8일(월)",
        emotion: "ghost",
        img: "pickup6.jpg",
    },
    {
        title: "NO LIMIT! 카운트다운 2024",
        cont: "개최기간：2023년 12월 31일 (일) 19:00~2024년 1월 1일 (월) 21:00",
        emotion: "calendar",
        img: "pickup7.jpg",
    },
    {
        title: "“NO LIMIT!”",
        cont: "개최기간：2022년 3월 29일(화)~ (일본어 페이지 한정)",
        emotion: "earth",
        img: "pickup8.jpg",
    },
    {
        title: "귀멸의 칼날 XR 라이드 ~꿈속을 달리는 무한열차~",
        cont: "개최기간：2024년 2월 1일(목)~6월 9일(일)",
        emotion: "bolt",
        img: "pickup9.jpg",
    },
    
];
