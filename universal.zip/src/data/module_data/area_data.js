export const area_data = [
    {
        name : '슈퍼 닌텐도 월드™',
        img : 'area/1.jpg',
        txt : '#WE ARE MARIO!!',
    },
    {
        name : '위저딩 월드 오브 해리 포터™',
        img : 'area/2.jpg',
        txt : '압도적인 스케일과 섬세한 디테일'
    },
    {
        name : '미니언 파크',
        img : 'area/3.jpg',
        txt : '엄청나게 즐거운 미니언 파크에서 전 인류가 신나게 즐긴다!'
    },
    {
        name : '유니버설 원더랜드',
        img : 'area/4.jpg',
        txt : '가족 모두의 신나는 웃음이 2배로 늘어납니다.'
    },
    {
        name : '할리우드',
        img : 'area/5.jpg',
        txt : '화려한 할리우드 거리의 모습'
    },
    {
        name : '뉴옥',
        img : 'area/6.jpg',
        txt : '1930년대의 뉴욕을 재현',
    },
    {
        name : '샌프란시스코',
        img : 'area/7.jpg',
        txt : '활기와 개방감이 가득한 항구 도시'
    },
    {
        name : '쥬라기 공원',
        img : 'area/8.jpg',
        txt :  '공룡들이 서식하는 아열대의 정글'
    },
    {
        name : '애머티 빌리지',
        img : 'area/9.jpg',
        txt : '아주 유명한 재난 영화의 무대가 된 어촌'
    },
    {
        name : '워터 월드',
        img : 'area/10.jpg',
        txt : '해상에 떠 있는 근미래 도시'
    },
];