export const seasonalMuData = [
    {
        'title' : '기간 한정! 크리스마스 프리미엄 코스',
        
    }
];