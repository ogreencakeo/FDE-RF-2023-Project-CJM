export const fmenu = [
    {
        footerMenu1 : [
            {
                txt : '日本語',
            },
            {
                txt : '简体中文',
            },
            {
                txt : '한국어',
            },
            {
                txt : '繁體中文',
            }
        ]
    },
    {
        footerMenu2 : [
            {
                txt : '저작권과 상표',
            },
            {
                txt : '이 사이트에 대하여',
            },
            {
                txt : '개인정보 보호정책',
            },
            {
                txt : '사이트맵',
            },
        ]
    }
];