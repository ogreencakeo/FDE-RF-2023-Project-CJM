// Function/indexFn.js

export const getWaveText = () => {
    return 'Universal Studios';  // 또는 필요한 텍스트로 변경
};
